/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils_redir.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinhuang <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/28 20:21:45 by jinhuang          #+#    #+#             */
/*   Updated: 2025/07/03 16:08:39 by jinhuang         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	check_standard_fd(int fd)
{
	if (fd == STDIN_FILENO || fd == STDOUT_FILENO || fd == STDERR_FILENO)
		return (1);
	return (0);
}

int	check_cmd_standard(t_shell *sh)
{
	if (check_standard_fd(sh->curr_cmd->fd_in) && \
			check_standard_fd(sh->curr_cmd->fd_out) && \
		sh->curr_cmd->infile == NULL && sh->curr_cmd->outfile == NULL)
		return (1);
	return (0);
}
